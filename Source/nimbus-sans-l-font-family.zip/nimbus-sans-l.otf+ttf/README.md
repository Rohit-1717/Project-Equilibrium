
AUTHOR
======
[(URW)++](https://www.urwpp.de); Cyrillic glyphs added by Valek Filippov

LICENSE
=======
[General Public License (GPL)](http://www.fsf.org/licenses/gpl.html)

